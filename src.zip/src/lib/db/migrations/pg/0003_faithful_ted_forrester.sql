ALTER TABLE "knowledge_base" DROP CONSTRAINT "knowledge_base_user_id_user_id_fk";
